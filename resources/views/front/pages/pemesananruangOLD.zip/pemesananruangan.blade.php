@extends('front.layout.master')

@section('content')	

<div class="container">

  <div class="container-contact100">
		@if(empty(isset($_GET['nama_ruang'])))
		<div class="wrap-contact100">
			<form action="{{ route('pemesananruangan.submit') }}" method="POST" class ="contact100-form validate-form">
				{!! csrf_field() !!}
				<span class="contact100-form-title">
					Form Pemesanan Ruangan
				</span>	

				<div class="wrap-input100 validate-input bg1" data-validate="Nomor Pemesanan Ruangan">
					<span class="label-input100">Nomor Pemesanan Ruangan *</span>
					<input class="input100" type="text" name="no_pemesanan_ruangan" placeholder="Masukkan Nomor Pemesanan Ruangan">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "Tanggal">
					<span class="label-input100">Tanggal *</span>
					<input class="input100" type="date" name="tanggal" placeholder="Masukkan Tanggal">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Pemohon *</span>
					<input class="input100" type="text" name="pemohon" value="{{ $pemohon["nama"] }}" readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "Waktu">
					<span class="label-input100">Waktu</span>
					<input class="input100" type="time" name="waktu" placeholder="Masukkan Waktu">
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate="Nama Acara">
					<span class="label-input100">Nama Acara *</span>
					<input class="input100" type="text" name="nama_acara" placeholder="Masukkan Nama Acara">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "Jumlah Peserta">
					<span class="label-input100">Jumlah Peserta *</span>
					<input class="input100" type="number" name="jumlah_peserta" placeholder="Masukkan Jumlah Peserta ">
				</div>

				<div class="wrap-input100 input100-select rs1-wrap-input100" >
					<span class="label-input100">ID Ruang *</span>
					<div>
						<select class="js-select2" name="id_ruang">
							<option>Please chooses</option>
							@foreach($array_ruang as $ruangan)
							  <option value={{ $ruangan["id"] }}>{{ $ruangan["nama_ruang"] }}</option>
							@endforeach
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 input100-select rs1-wrap-input100" >
					<span class="label-input100">Penanggung Jawab *</span>
					<div>
						<select class="js-select2" name="penanggung_jawab">
							<option>Please chooses</option>
							@foreach($array_pj_ruang as $manajer)
							  <option value={{ $manajer["id"] }}>{{ $manajer["nama"] }}</option>
							@endforeach
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "File Layout">
					<span class="label-input100">File Layout *</span>
					<input class="input100" type="file" name="file_layout" placeholder="Masukkan File Layout">
				</div>

				<div class="wrap-input100 validate-input bg0 rs1-alert-validate" data-validate = "Masukkan Keterangan">
					<span class="label-input100">Keterangan</span>
					<textarea class="input100" name="keterangan" placeholder="Keterangan Disini..."></textarea>
				</div>

				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Submit
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
		</div>
		@endif

		@if(isset($_GET['nama_ruang']))
			<div class="wrap-contact100">
			<form action="{{ route('pemesananruangan.submit') }}" method="POST" class ="contact100-form validate-form">
				{!! csrf_field() !!}
				<span class="contact100-form-title">
					Form Pemesanan Ruangan
				</span>	

				<div class="wrap-input100 validate-input bg1" data-validate="Nomor Pemesanan Ruangan">
					<span class="label-input100">Nomor Pemesanan Ruangan *</span>
					<input class="input100" type="text" name="no_pemesanan_ruangan" placeholder="Masukkan Nomor Pemesanan Ruangan">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Tanggal *</span>
					<input class="input100" type="text" name="tanggal" value="{{$_GET['tanggal']}}" readonly>
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Pemohon *</span>
					<input class="input100" type="text" name="pemohon" value="{{ $pemohon["nama"] }}" readonly>
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100"">
					<span class="label-input100">Waktu</span>
					<input class="input100" type="time" name="waktu" value="{{$_GET['waktu']}}">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100"" data-validate="Nama Acara">
					<span class="label-input100">Nama Acara *</span>
					<input class="input100" type="text" name="nama_acara" placeholder="Masukkan Nama Acara">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100"">
					<span class="label-input100">Jumlah Peserta *</span>
					<input class="input100" type="number" name="jumlah_peserta" value="{{$_GET['jumlah_peserta']}}" readonly>
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100"">
					<span class="label-input100">Ruang</span>
					<input class="input100" type="hidden" name="id_ruang" value="{{$_GET['id_ruang']}}" readonly>
					<input class="input100" type="text" name="nama_ruang" value="{{$_GET['nama_ruang']}}" readonly>
				</div>

				<div class="wrap-input100 input100-select rs1-wrap-input100" >
					<span class="label-input100">Penanggung Jawab *</span>
					<div>
						<select class="js-select2" name="penanggung_jawab">
							<option>Please chooses</option>
							@foreach($array_pj_ruang as $manajer)
							  <option value={{ $manajer["id"] }}>{{ $manajer["nama"] }}</option>
							@endforeach
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "File Layout">
					<span class="label-input100">File Layout *</span>
					<input class="input100" type="file" name="file_layout" placeholder="Masukkan File Layout">
				</div>

				<div class="wrap-input100 validate-input bg0 rs1-alert-validate" data-validate = "Masukkan Keterangan">
					<span class="label-input100">Keterangan</span>
					<textarea class="input100" name="keterangan" placeholder="Keterangan Disini..."></textarea>
				</div>

				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Submit
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
		</div>			
		@endif
	</div>

</div><!-- /.container -->
@stop